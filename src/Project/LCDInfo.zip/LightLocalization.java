package Project;

public class LightLocalization {
	
	
	

public static void Localize(){
		
	}
}
